package banque;

public class Banque {

}
